function setup() 
{  
  createCanvas(400, 400);
  background(200, 220, 245); // Light blue background

  // Angle mode to degrees
  angleMode(DEGREES);

  // Raindrops using a "for" loop
  for (let i = 0; i < 50; i++) {  // More raindrops to make it look better
    let x = random(width);
    let y = random(height);
    let s = random(0.7, 1.2); // Scale factor
    // Push and pop transformations
    push();
    translate(x, y);
    scale(s);
    rotate(180 + random(-15, 15)); // The 180 is so it doesn't look like the rain is falling up
    drawRaindrop();
    pop();
  }

  // Number of Raindrops counted
  let totalRaindrops = countRaindrops();
  print("Total raindrops: " + totalRaindrops);
}

// Function to draw a raindrop shape using ellipse and triangle
function drawRaindrop() {
  noStroke();

  // Random shades of blue for the raindrop so its not one color and looks bad
  let Bluecolor = color(0, 100, random(200, 255)); 
  fill(Bluecolor);

  // Main drop body
  ellipse(0, 0, 15, 30); 

  // Tail of the drop
  fill(Bluecolor);  // Making sure the triangles are the same color as rest of the raindrop body
  stroke(Bluecolor); 
  strokeWeight(1);
  triangle(-5, 10, 5, 10, 0, 25);  // Triangle located at the bottom of the ellipse but really its at the top because I flipped the rain and I didn't want to mess with the triangle much
}

// Function to spit out the number of raindrops
function countRaindrops() {
  return 50;  // gives the number to show how many raindrops I have
}
