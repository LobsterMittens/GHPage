let IMG_1, IMG_2, IMG_png;

function preload() {
  IMG_1 = loadImage('images/IMG_1.jpg'); 
  IMG_2 = loadImage('images/IMG_2.jpg'); 
  IMG_png = loadImage('images/IMG_png.PNG');
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  textFont('Helvetica'); // Font
  stroke(4);
  fill(255);
}

function draw() {
  background(200); 

  // A Nice Image of My Beagle Lilly sticking her tongue out at the camera in a fixed position
  image(IMG_1, 100, 100, 200, 200); 

  // Lilly eating a huge bone in a position that uses mouseX and mouseY
  image(IMG_2, mouseX - 100, mouseY - 100, 200, 200);

  // A Png of Lilly staring at the camera while it looks like behind her she is biting her own tail controlled by mouseX and mouseY
  image(IMG_png, mouseX - 50, mouseY - 50, 150, 150); 

  // Random text
  textSize(32);
  text('My Dog Lilly', 50, 50, 300, 100); // Width and height for text
}
