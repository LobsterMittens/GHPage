      let circleX = [];
      let circleY = [];
      let numCircles = 10;

      function setup() {
        createCanvas(400, 400); // Canvas size
        noStroke();
        for (let i = 0; i < numCircles; i++) {
          circleX[i] = random(width);  // Random values for array
          circleY[i] = random(height);
        }
        print("Length of circleX array: " + circleX.length); // Array Length
      }

      function draw() {
        background(0, 255, 0); // Spooky green halloween background!

        for (let i = 0; i < numCircles; i++) {
          circleY[i] += random(-2, 2);
          circleX[i] += random(-2, 2);

          if (circleX[i] > width) circleX[i] = 0;
          if (circleX[i] < 0) circleX[i] = width;
          if (circleY[i] > height) circleY[i] = 0;
          if (circleY[i] < 0) circleY[i] = height;

          fill(255, 140, 0); // Orange
          ellipse(circleX[i], circleY[i], 50, 50); // Close enough pumpkins 
        }

        // Mouse position
        circleX[numCircles - 1] = mouseX;
        circleY[numCircles - 1] = mouseY;

        fill(255, 0, 255); // Purple Mouse
        ellipse(mouseX, mouseY, 50, 50); // Last circle follows the mouse
      }